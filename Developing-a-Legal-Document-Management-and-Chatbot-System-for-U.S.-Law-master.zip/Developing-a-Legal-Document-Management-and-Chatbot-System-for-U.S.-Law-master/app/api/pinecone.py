from fastapi import APIRouter, File, UploadFile, HTTPException
from fastapi.responses import JSONResponse

from ..dependencies.auth import verify_token, create_access_token


from pinecone.grpc import PineconeGRPC as PineconeGRPC_Client
from langchain_pinecone import Pinecone as LangChainPinecone


from pinecone import ServerlessSpec

from langchain_openai import OpenAI, OpenAIEmbeddings


from langchain.chains import create_retrieval_chain
from langchain.chains.combine_documents import create_stuff_documents_chain


from langchain_community.document_loaders import TextLoader
from langchain_text_splitters import CharacterTextSplitter

from langchain.prompts import PromptTemplate

import os
from dotenv import load_dotenv
load_dotenv()
from langchain.text_splitter import RecursiveCharacterTextSplitter
from pydantic import BaseModel


from ..utils.PDF_Loader import load_pdf_document


llm = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
embeddings=OpenAIEmbeddings(api_key='sk-proj-S1Geig55Gagb5NcCxPDjT3BlbkFJznF1JG9n5VEEMQF2sQJ6')
pc = PineconeGRPC_Client(api_key=os.environ.get('PINECONE_API_KEY'))
text_splitter = CharacterTextSplitter(
    separator=r"\n+",  # Regex to match one or more newlines
    chunk_size=1000,    # Adjust chunk size as needed
    chunk_overlap=200,    # Optional overlap
    is_separator_regex=True
)



router = APIRouter()



@router.post("/add_document")
async def add_document(file: UploadFile = File(...)):
    print('FILE CONTENT TYPE',file)
    try:
        # Check if the uploaded file is a PDF
        if not file.filename.endswith('pdf'):
            raise HTTPException(status_code=400, detail="Invalid file type. Only PDFs are allowed.")


        # Save the uploaded file locally (optional - adjust path as needed)
        file_location = f"./app/uploaded_files/{file.filename}"
        with open(file_location, "wb") as f:
            f.write(await file.read())

        try:
            documents = load_pdf_document(file_location,file.filename)
            pcv= LangChainPinecone(index_name='uslaw',embedding=embeddings,pinecone_api_key=os.environ.get('PINECONE_API_KEY'),namespace=file.filename)

            pcv.add_documents(documents)
            # print('DOCUMENT TEXT',text_splitter.split_documents(documents))
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Error processing PDF: {str(e)}")
        finally:
            os.remove(file_location)  # Optional cleanup

        return JSONResponse(content={"message": "PDF file uploaded successfully", "file_location": 'file_location'})
    except Exception as err:
        print('ERROR',err)




class ChatRequest(BaseModel):
    file_name: str
    prompt: str

@router.post("/chat")
async def chat(request: ChatRequest):
    file_name= request.file_name
    prompt= request.prompt
    pcv= LangChainPinecone(index_name='uslaw',embedding=embeddings,pinecone_api_key=os.environ.get('PINECONE_API_KEY'),namespace=file_name)
    retriever = pcv.as_retriever(search_type="similarity", search_kwargs={"k": 7})
        
    retrieval_qa_chat_prompt = PromptTemplate(
    input_variables=["context", "input"],
    template = '''
        %INSTRUCTIONS:
        You are an AI assistant designed to answer questions accurately and concisely based on the provided context. If the context does not contain relevant information, respond with "The context does not provide an answer to this question" and politely ask for clarification if needed.

        %CONTEXT:
        {context}

        %USER QUESTION:
        {input}

        %RESPONSE:
    '''
    )

    combine_docs_chain = create_stuff_documents_chain(
        llm, retrieval_qa_chat_prompt
    )
    retrieval_chain = create_retrieval_chain(retriever, combine_docs_chain)    
    print('RETRIEVAL CHAIN INVOKE',retrieval_chain.invoke({'input':'what'}))
    response = retrieval_chain.invoke({"input": prompt})

    return {
        "file_name": request.file_name,
        "response":response ['answer']  
    }