from fastapi import APIRouter, Depends
from ..dependencies.auth import verify_token, create_access_token

router = APIRouter()

@router.get("/login")
async def login():
    # Here, you can check if the current user has access to the item
    access_token = create_access_token(data={"sub": 'Mohsin'})

    return {"access_token": access_token, "token_type": "bearer"}



@router.get("/check_jwt")
async def check_jwt(jwt_data: dict = Depends(verify_token)):
    # Here, you can check if the current user has access to the item
    print(jwt_data)

    return {'response':'verfication succesful'}

