# utils/pdf_loader.py
from langchain_community.document_loaders import PyPDFLoader
import re
from langchain_text_splitters import CharacterTextSplitter





def clean_pdf_text(pdf,file_name:str):

    text=""
    text = pdf.page_content.replace("\n", " ")  # Replace all newlines with a space
    text = re.sub(r'\s+', ' ', text)  # Replace multiple spaces with a single space
    # print(text)
    pdf.page_content=text
    pdf.metadata['file_name']=file_name
    print('XXXX_PDF_xxxXX',pdf.metadata)







def load_pdf_document(file_path: str,file_name:str) -> str:
    """
    Loads text from a PDF file using PyPDFLoader and returns the extracted text.
    """
    loader = PyPDFLoader(file_path=file_path)
    documents = loader.load()

    for doc in documents:
        clean_pdf_text(doc,file_name)
    

    # print('THE DOCUMENT',documents)

    # Extract and concatenate text from all pages
    return documents
