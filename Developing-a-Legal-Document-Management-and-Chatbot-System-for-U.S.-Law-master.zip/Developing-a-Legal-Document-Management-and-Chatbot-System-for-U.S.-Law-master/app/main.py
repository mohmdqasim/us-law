from fastapi import FastAPI
from .api import auth, pinecone

app = FastAPI()

# Include the routers from different modules
app.include_router(auth.router)

app.include_router(pinecone.router)
