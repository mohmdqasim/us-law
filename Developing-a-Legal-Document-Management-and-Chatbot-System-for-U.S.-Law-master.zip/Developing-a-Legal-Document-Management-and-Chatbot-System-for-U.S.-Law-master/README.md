# Creating a Virutal Enviroment in Python


1. Navigate to the directory via terminal where you want to setup a python virtual enviroment.
2. Within the terminal enter the following command:
	```sh
	python3 -m venv .venv
	```
3. Create a text file by the name of [requirements.txt](:/8a2ab28225a14d8d928dc1c5cff89639) and define the python libraries you want to install.
4. To Activate VENV
	```sh
	.\.venv\Scripts\activate
	```
	OR In MAC
	```sh
	source .venv/bin/activate
	```
5. Command to upgrade  `pip`:
	```py
	.venv\Scripts\python.exe -m pip install --upgrade pip
	```
6. Finally enter the following command in the terminal to install the python libraries:
	```sh
	pip install -r  .\requirements.txt
	```
