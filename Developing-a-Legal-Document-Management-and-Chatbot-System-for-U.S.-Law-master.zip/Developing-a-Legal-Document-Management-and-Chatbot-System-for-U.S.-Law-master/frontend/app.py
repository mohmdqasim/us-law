# # import streamlit as st
# # import requests
# # from io import BytesIO
# # from pinecone.grpc import PineconeGRPC as PineconeGRPC_Client
# # import os

# # # FastAPI backend URL
# # API_URL = "http://localhost:8000/add_document"  # Update with the correct FastAPI URL

# # pc = PineconeGRPC_Client(api_key=os.environ.get('PINECONE_API_KEY'))
# # pc_indx=pc.Index('uslaw')


# # # Initialize session state for uploaded files and conversation history
# # if "pdf_files" not in st.session_state:
# #     st.session_state.pdf_files = []
# # if "doc_files" not in st.session_state:
# #     st.session_state.doc_files = []
# # if "csv_files" not in st.session_state:
# #     st.session_state.csv_files = []
# # if "conversation" not in st.session_state:
# #     st.session_state.conversation = []

# # def main():
# #     st.set_page_config(page_title="File Upload and Chat Interface")

# #     if "page" not in st.session_state:
# #         st.session_state.page = "page1"  # Start with page1 by default

# #     if st.session_state.page == "page1":
# #         page1()
# #     elif st.session_state.page == "page2":
# #         page2()

# # def page1():
# #     st.title("File Upload and Selection")

# #     # Upload button with file input
# #     uploaded_file = st.file_uploader("Upload a PDF file", type=["pdf"])
# #     if uploaded_file is not None:
# #         if uploaded_file.type == "application/pdf":
# #             # Call the FastAPI endpoint to process the PDF
# #             response = upload_pdf_to_api(uploaded_file)
# #             if response and response.status_code == 200:
# #                 st.success(f"PDF uploaded successfully: {uploaded_file.name}")
# #             else:
# #                 st.error(f"Failed to upload PDF: {response.text if response else 'Unknown error'}")

# #     # Fetch and display uploaded PDFs from Pinecone namespaces
# #     try:
# #         index_stats = pc_indx.describe_index_stats()
# #         namespaces = index_stats.get("namespaces", {})
# #         pdf_list = [namespace for namespace in namespaces.keys() if namespace.endswith(".pdf")]

# #         st.write("### Select a PDF file to proceed:")
# #         cols = st.columns(3)  # Arrange buttons in 3 columns
# #         for idx, pdf_name in enumerate(pdf_list):
# #             col = cols[idx % 3]
# #             with col:
# #                 if st.button(f"PDF - {pdf_name}", key=f"pdf_{idx}"):
# #                     # Navigate to Page 2 and store the selected file_name
# #                     st.session_state.page = "page2"
# #                     st.session_state.selected_file = pdf_name  # Pass the selected file name

# #     except Exception as e:
# #         st.error(f"Error fetching uploaded PDFs: {e}")


# # def page2():
# #     st.title("Chat Interface")

# #     # Ensure a file was selected in Page 1
# #     if "selected_file" not in st.session_state:
# #         st.warning("No file selected. Returning to Page 1...")
# #         st.session_state.page = "page1"
# #         return

# #     file_name = st.session_state.selected_file

# #     st.write(f"### Chat with AI (File: {file_name})")

# #     # Display conversation history
# #     for user_text, ai_response in st.session_state.conversation:
# #         st.write(f"**User:** {user_text}")
# #         st.write(f"**AI:** {ai_response}")

# #     # User Prompt Input
# #     user_prompt = st.text_input("Your message:", key="user_input")
    
# #     if st.button("Send") and user_prompt:
# #         # Call the /chat API with the user input and file_name
# #         api_response = call_chat_api(file_name, user_prompt)
# #         if api_response and api_response.status_code == 200:
# #             ai_response = api_response.json().get("response", "No response received.")
# #             # Append the conversation to the session state
# #             st.session_state.conversation.append((user_prompt, ai_response))
# #         else:
# #             st.error(f"Failed to get a response: {api_response.text if api_response else 'Unknown error'}")

# #     # Back button to navigate back to Page 1
# #     if st.button("Back"):
# #         st.session_state.page = "page1"


# # def call_chat_api(file_name, user_prompt):
# #     """Call the FastAPI /chat endpoint with the user prompt and file_name."""
# #     url = "http://localhost:8000/chat"  # Update with your FastAPI host/port
# #     payload = {"file_name": file_name, "prompt": user_prompt}
# #     try:
# #         response = requests.post(url, json=payload)
# #         return response
# #     except Exception as e:
# #         st.error(f"Error calling /chat API: {e}")
# #         return None

# # def generate_ai_response(user_prompt):
# #     responses = {
# #         "hello": "Hi, how can I help you?",
# #         "how are you": "I'm here to assist you! How can I help?",
# #         "tell me a joke": "Why don't scientists trust atoms? Because they make up everything!",
# #         "bye": "Goodbye! Feel free to come back if you have more questions."
# #     }
# #     return responses.get(user_prompt.lower(), "I'm here to help! Please ask a question.")

# # if __name__ == "__main__":
# #     main()















# import streamlit as st
# import requests
# from pinecone.grpc import PineconeGRPC as PineconeGRPC_Client
# import os

# # FastAPI backend URLs
# ADD_DOCUMENT_API_URL = "http://localhost:8000/add_document"
# CHAT_API_URL = "http://localhost:8000/chat"

# pc = PineconeGRPC_Client(api_key=os.environ.get('PINECONE_API_KEY'))
# pc_indx = pc.Index('uslaw')

# # Initialize session state
# if "pdf_files" not in st.session_state:
#     st.session_state.pdf_files = []
# if "conversation" not in st.session_state:
#     st.session_state.conversation = []
# if "selected_file" not in st.session_state:
#     st.session_state.selected_file = None

# def main():
#     st.set_page_config(page_title="PDF Chat App")

#     if "page" not in st.session_state:
#         st.session_state.page = "page1"  # Default to page1

#     if st.session_state.page == "page1":
#         page1()
#     elif st.session_state.page == "page2":
#         page2()

# def page1():
#     st.title("File Upload and Selection")

#     # Upload a new PDF
#     uploaded_file = st.file_uploader("Upload a PDF file", type=["pdf"])
#     if uploaded_file:
#         response = upload_pdf_to_api(uploaded_file)
#         if response and response.status_code == 200:
#             st.success(f"PDF uploaded successfully: {uploaded_file.name}")
#         else:
#             st.error(f"Failed to upload PDF: {response.text if response else 'Unknown error'}")

#     # Fetch and display existing PDF namespaces
#     try:
#         index_stats = pc_indx.describe_index_stats()
#         namespaces = index_stats.get("namespaces", {})
#         pdf_list = [namespace for namespace in namespaces.keys() if namespace.endswith(".pdf")]

#         st.write("### Available PDF Files:")
#         cols = st.columns(3)  # Display buttons in 3 columns
#         for idx, pdf_name in enumerate(pdf_list):
#             col = cols[idx % 3]
#             with col:
#                 if st.button(pdf_name, key=f"pdf_{idx}"):
#                     st.session_state.selected_file = pdf_name
#                     st.session_state.page = "page2"  # Navigate to Page 2

#     except Exception as e:
#         st.error(f"Error fetching PDF list: {e}")

# def page2():
#     st.title("Chat Interface")

#     if not st.session_state.selected_file:
#         st.warning("No file selected. Redirecting to Page 1...")
#         st.session_state.page = "page1"
#         return

#     file_name = st.session_state.selected_file
#     st.write(f"### Chat with AI (Context: {file_name})")

#     # Display chat history
#     for user_text, ai_response in st.session_state.conversation:
#         st.write(f"**You:** {user_text}")
#         st.write(f"**AI:** {ai_response}")

#     # User input for chatting
#     user_prompt = st.text_input("Enter your message:")
#     if st.button("Send") and user_prompt:
#         response = call_chat_api(file_name, user_prompt)
#         if response and response.status_code == 200:
#             ai_response = response.json().get("response", "No response received.")
#             st.session_state.conversation.append((user_prompt, ai_response))
#         else:
#             st.error(f"Failed to get response: {response.text if response else 'Unknown error'}")

#     # Back button
#     if st.button("Back"):
#         st.session_state.page = "page1"

# def upload_pdf_to_api(uploaded_file):
#     """Send the uploaded PDF to the FastAPI backend."""
#     files = {"file": (uploaded_file.name, uploaded_file, "application/pdf")}
#     try:
#         response = requests.post(ADD_DOCUMENT_API_URL, files=files)
#         return response
#     except Exception as e:
#         st.error(f"Error uploading PDF: {e}")
#         return None

# def call_chat_api(file_name, user_prompt):
#     """Call the /chat API endpoint with the selected file and user prompt."""
#     payload = {"file_name": file_name, "prompt": user_prompt}
#     try:
#         response = requests.post(CHAT_API_URL, json=payload)
#         return response
#     except Exception as e:
#         st.error(f"Error calling /chat API: {e}")
#         return None

# if __name__ == "__main__":
#     main()







import streamlit as st
import requests
import os
from pinecone.grpc import PineconeGRPC as PineconeGRPC_Client

# FastAPI backend URLs
API_URL=os.environ.get("API_URL")
CHAT_API_URL = f"{API_URL}/chat"
ADD_DOCUMENT_API_URL = f"{API_URL}/add_document"

# Pinecone setup
pc = PineconeGRPC_Client(api_key=os.environ.get('PINECONE_API_KEY'))
pc_indx = pc.Index('uslaw')

# Initialize session state
if "selected_file" not in st.session_state:
    st.session_state.selected_file = None
if "conversation" not in st.session_state:
    st.session_state.conversation = []
if "latest_response" not in st.session_state:
    st.session_state.latest_response = ""  # Store the latest response

def main():
    st.set_page_config(page_title="PDF Chat App", layout="wide")

    st.title("PDF Chat Interface")

    # Sidebar for file selection and file upload
    with st.sidebar:
        # File upload button to add a new PDF
        uploaded_file = st.file_uploader("Upload a new PDF file", type=["pdf"])
        if uploaded_file is not None:
            response = upload_pdf_to_api(uploaded_file)
            if response and response.status_code == 200:
                st.success(f"PDF uploaded successfully: {uploaded_file.name}")
            else:
                st.error(f"Failed to upload PDF: {response.text if response else 'Unknown error'}")

        st.write("### Available PDF Files:")
        # Fetch and display uploaded PDFs from Pinecone namespaces
        try:
            index_stats = pc_indx.describe_index_stats()
            namespaces = index_stats.get("namespaces", {})
            pdf_list = [namespace for namespace in namespaces.keys() if namespace.endswith(".pdf")]

            for pdf_name in pdf_list:
                if st.button(pdf_name, key=pdf_name):
                    st.session_state.selected_file = pdf_name
                    st.session_state.conversation = []  # Clear conversation history when selecting a new file
                    st.session_state.latest_response = ""  # Clear the latest response

        except Exception as e:
            st.error(f"Error fetching PDF list: {e}")

    # Main content area
    if st.session_state.selected_file:
        file_name = st.session_state.selected_file
        st.write(f"### Chat with AI (Context: {file_name})")

        # Display conversation history
        # for user_text, ai_response in st.session_state.conversation:
        #     st.markdown(f"**You:** {user_text}")
        #     st.markdown(f"**AI:** {ai_response}")

        # User input for chatting
        user_prompt = st.text_input("Enter your prompt:")
        if st.button("Send"):
            # Call the API only if the input is not empty
            if user_prompt.strip():
                response = call_chat_api(file_name, user_prompt)
                if response and response.status_code == 200:
                    ai_response = response.json().get("response", "No response received.")
                    st.session_state.conversation.append((user_prompt, ai_response))  # Append new conversation
                    st.session_state.latest_response = ai_response  # Update the latest response
                else:
                    st.error(f"Failed to get response: {response.text if response else 'Unknown error'}")
            else:
                st.warning("Please enter a message before sending.")

        # Render the latest response immediately
        if st.session_state.latest_response:
            st.markdown(f"**AI Response:** {st.session_state.latest_response}")

    else:
        st.warning("Please select a PDF from the sidebar to start chatting.")

def upload_pdf_to_api(uploaded_file):
    """Call the /add_document API to upload the PDF file."""
    files = {"file": uploaded_file}
    try:
        response = requests.post(ADD_DOCUMENT_API_URL, files=files)
        return response
    except Exception as e:
        st.error(f"Error uploading PDF: {e}")
        return None

def call_chat_api(file_name, user_prompt):
    """Call the /chat API endpoint with the selected file and user prompt."""
    payload = {"file_name": file_name, "prompt": user_prompt}
    try:
        response = requests.post(CHAT_API_URL, json=payload)
        return response
    except Exception as e:
        st.error(f"Error calling /chat API: {e}")
        return None

if __name__ == "__main__":
    main()
